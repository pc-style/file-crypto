Marketing 2024 export
-----------------------------------------

Contents:
- manifest.json: metadata for ingestion
- reports/: CSV summaries
- docs/checklist.yaml: validation checklist

This bundle was generated automatically for compliance review.
